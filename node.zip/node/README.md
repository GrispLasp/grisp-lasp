node
=====

A GRiSP application

Build
-----

    $ rebar3 compile

Deploy
------

    $ rebar3 grisp deploy
