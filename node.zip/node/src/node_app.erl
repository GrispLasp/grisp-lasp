%%%-------------------------------------------------------------------
%% @doc node application public API
%% @end
%%%-------------------------------------------------------------------

% /!\ NOTE :
% 3.1 Timer Module
% Creating timers using erlang:send_after/3 and erlang:start_timer/3 , is much more efficient than using the timers provided by the timer module in STDLIB.
% The timer module uses a separate process to manage the timers.
% That process can easily become overloaded if many processes create and cancel timers frequently (especially when using the SMP emulator).
% The functions in the timer module that do not manage timers (such as timer:tc/3 or timer:sleep/1),
% do not call the timer-server process and are therefore harmless.

-module(node_app).

-behaviour(application).

% -include("node.hrl").

%% Application callbacks
-export([start/2, stop/1]).

%%====================================================================
%% API
%%====================================================================
% TODO : find a way to get rid of lager, see commit below
% https://github.com/lasp-lang/lasp/pull/295/commits/e2f948f879145a5ff31cf5458201768ca97b406b
% application:which_applications().

start(_StartType, _StartArgs) ->
    {ok, Supervisor} = node:start(),
    io:format("Application Master has started app ~n"),
    {ok, Supervisor}.

%%--------------------------------------------------------------------

stop(_State) ->
    io:format("Application Master has stopped app~n"), ok.

%%====================================================================
%% Internal functions
%%====================================================================
