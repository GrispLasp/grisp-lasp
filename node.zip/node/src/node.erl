% @doc node public API.
% @end
-module(node).

% Callbacks
-export([start/0]).
-export([stop/1]).

%--- Callbacks -----------------------------------------------------------------

% start() ->
%     {ok, Sup} = node_sup:start_link(),
%     % application:ensure_all_started(node),
%     {ok, Sup}.
start() -> node_sup:start_link().

stop(_State) -> ok.
% file:get_cwd().
% application:get_all_env(node).
% application:get_all_env(lasp).
% application:get_all_env(partisan).
% application:get_all_env(lager).
% application:which_applications().
