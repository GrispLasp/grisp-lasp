### Versions

* OS: <!-- Your operating system and version -->
* GRiSP Toolchain: <!-- The Git SHA for the grisp-software repository -->
* Erlang: <!-- The version of Erlang you have installed -->
* Rebar: <!-- Run `rebar3 version` to get this -->

### Description

<!-- Description about the problem here, steps to reproduce etc. -->


<!-- Please attach any relevant files, such as build logs, error messages etc. -->
